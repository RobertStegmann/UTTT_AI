import GameState as g
import random as r

class RandomAI:
    
    def chooseMove(game):
        if game.currentBoard == 9:
            possibleMoves = RandomAI.chooseMoveFullBoard(game)
        else:
            possibleMoves = RandomAI.chooseMoveSingleGrid(game)
        return possibleMoves[r.randrange(len(possibleMoves))]       
    
    def chooseMoveFullBoard(game):
        possibleMoves = []
        for b in range(0,9):
            coord = g.GameState.boardToCoord(b)
            if not game.boardsWon[coord[0]][coord[1]]:
                for i in range(0,3):
                    for j in range(0,3):
                        if not game.board[b][i][j]:
                            possibleMoves.append((b,i,j))
        return possibleMoves
    
    def chooseMoveSingleGrid(game):
        possibleMoves = []
        for i in range(0,3):
            for j in range(0,3):
                if not game.board[game.currentBoard][i][j]:
                    possibleMoves.append((game.currentBoard,i,j))
        return possibleMoves            
